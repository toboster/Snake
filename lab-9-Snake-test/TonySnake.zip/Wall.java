import java.awt.Point;

/**
 * @author Tony Nguyen 11/30/17
 */
@SuppressWarnings("serial")
public class Wall extends GameObject {

    public Wall(int x, int y){
        super(x,y);
    }

    public Wall(Point p){
        super(p);
    }

    @Override
    public char printSymbol(){
        return 'X';
    }
}
